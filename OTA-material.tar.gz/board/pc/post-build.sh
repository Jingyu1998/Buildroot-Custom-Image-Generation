#!/bin/sh

set -eu

# define log function
WHITE_TXT_BLACK_BG="\033[30;107m"
RESET_COLOR="\033[0m"

log() {
    echo "$WHITE_TXT_BLACK_BG>>>      $1$RESET_COLOR"
}

BOARD_DIR=$(dirname "$0")

# Detect boot strategy, EFI or BIOS
if [ -d "$BINARIES_DIR/efi-part/" ]; then
    cp -f "$BOARD_DIR/grub-efi.cfg" "$BINARIES_DIR/efi-part/EFI/BOOT/grub.cfg"
    cat > "$TARGET_DIR/etc/ota-version" << EOF
Version: 1.0.0
Build: origin
EOF
    log "Create OTA version metadata in output/target/etc/ota-version"
    cp -f "$BOARD_DIR/install.sh" "$TARGET_DIR/root/install.sh"
    log "Install OTA update script in output/target/root/install.sh"
    cp -f "$BOARD_DIR/S99ota-boot-check" "$TARGET_DIR/etc/init.d/S99ota-boot-check"
    log "Install OTA boot check script in output/target/etc/init.d/S99ota-boot-check"
else
    cp -f "$BOARD_DIR/grub-bios.cfg" "$TARGET_DIR/boot/grub/grub.cfg"

    # Copy grub 1st stage to binaries, required for genimage
    cp -f "$TARGET_DIR/lib/grub/i386-pc/boot.img" "$BINARIES_DIR"
fi

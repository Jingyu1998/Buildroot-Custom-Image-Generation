#!/bin/sh

set -eu

OPTION="$1"

case "$OPTION" in
    --update)
        MODE="update"   
        ;;
    --restore)
        MODE="restore"
        ;;
    *)
        echo "Usage: $0 --update|--restore"
        exit 1
        ;;
esac

# define log function
WHITE_TXT_BLACK_BG="\033[30;107m"
RESET_COLOR="\033[0m"

if [ $MODE == "update" ]; then
    LOG_TAG="OTA update"
elif [ $MODE == "restore" ]; then
    LOG_TAG="restore"
fi

log() {
    echo -e "$WHITE_TXT_BLACK_BG>>> $1 $RESET_COLOR"
    logger -t "$LOG_TAG" "$1" 
}

## find the active root filesystem by PARTLABEL
ACTIVE_ROOTFS_PARTLABEL=$(findmnt -n -o PARTLABEL /) 

if [ $ACTIVE_ROOTFS_PARTLABEL == "rootfsA" ]; then
    INACTIVE_ROOTFS_PARTLABEL="rootfsB"
elif [ $ACTIVE_ROOTFS_PARTLABEL == "rootfsB" ]; then
    INACTIVE_ROOTFS_PARTLABEL="rootfsA"
fi

## find the device name of inactive root filesystem 
INACTIVE_ROOTFS_DEVNAME=$(blkid -t PARTLABEL="$INACTIVE_ROOTFS_PARTLABEL" -o device)

log "active slot is $ACTIVE_ROOTFS_PARTLABEL"
log "inactive slot is $INACTIVE_ROOTFS_PARTLABEL"
log "starting to $MODE in $INACTIVE_ROOTFS_PARTLABEL"

## mount the inactive root filesystem
mkdir -p /mnt/target
mount "$INACTIVE_ROOTFS_DEVNAME" /mnt/target

## find the device name of data partition 
DATA_DEVNAME=$(blkid -t PARTLABEL="data" -o device)

## mount the data partition
mkdir -p /mnt/data
mount $DATA_DEVNAME /mnt/data

## extract rootfs_update.tar to workspace
rm -rf /tmp/wkspace
mkdir -p /tmp/wkspace

if [ "$MODE" == "update" ]; then
    tar -xf /mnt/data/rootfs_update.tar -C /tmp/wkspace
elif [ "$MODE" == "restore" ]; then
    tar -xf /mnt/data/rootfs_origin.tar -C /tmp/wkspace 
fi

## umount the data partition
umount /mnt/data

## function for store file result in /var/log/messages
log_file() {
    local file="$1"

    while IFS= read -r line
    do
        log "    $line"
    done < "$file"
}

## check the /etc/ota-version before rsync
log "check the inactive rootfs /etc/ota-version before rsync"
log_file /mnt/target/etc/ota-version

## rsync 
rsync -a --delete /tmp/wkspace/ /mnt/target/
log "finished rsync"

## check the /etc/ota-version after rsync
log "check the inactive rootfs /etc/ota-version after rsync"
log_file /mnt/target/etc/ota-version

## umount the inactive rootfs
umount /mnt/target

## cleanup the workspace
rm -rf /tmp/wkspace

## find the device name of boot partition 
BOOT_DEVNAME=$(blkid -t PARTLABEL="boot" -o device)

## mount the boot partition
mkdir -p /mnt/boot
mount $BOOT_DEVNAME /mnt/boot 

CURRENT_SAVED_ENTRY=$(
    grub-editenv /mnt/boot/EFI/BOOT/grubenv list |
    awk -F= '/saved_entry/ {print $2}'
)

## function for store grubenv result in /var/log/messages
log_grubenv() {
    grub-editenv /mnt/boot/EFI/BOOT/grubenv list |
    while IFS= read -r line
    do
        log "    $line"
    done
}

## list all of the grub environment variable before edit it
log "list all of the grub environment variable before edit it"
log_grubenv

## edit the grub environment variable
grub-editenv /mnt/boot/EFI/BOOT/grubenv set saved_entry=$INACTIVE_ROOTFS_PARTLABEL

log "reset the grubenv saved_entry $CURRENT_SAVED_ENTRY to $INACTIVE_ROOTFS_PARTLABEL for next boot"

if [ "$MODE" == "update" ]; then
    grub-editenv /mnt/boot/EFI/BOOT/grubenv set boot_success=0
    log "reset the grubenv boot_success to 0"

    grub-editenv /mnt/boot/EFI/BOOT/grubenv set boot_attempt=0
    log "reset the grubenv boot_attempt to 0"
fi

## list all of the grub environment variable after edit it
log "Final result of the grub environment variable"
log_grubenv

## umount the boot partition
umount /mnt/boot

if [ "$MODE" == "update" ]; then
    log "Inactive $INACTIVE_ROOTFS_PARTLABEL pending verification"
elif [ "$MODE" == "restore" ]; then
    log "Inactive $INACTIVE_ROOTFS_PARTLABEL finish restore"
fi

log "You should manually reboot"

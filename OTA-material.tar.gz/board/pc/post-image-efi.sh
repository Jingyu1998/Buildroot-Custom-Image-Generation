#!/bin/sh

set -eu

# define log function
white_txt_black_bg="\033[30;107m"
reset_color="\033[0m"

log() {
    echo "$white_txt_black_bg>>>      $1$reset_color"
}

# 1. 產生兩個隨機且合法的 UUID（用於 A/B 分割區）
UUID_A=$(uuidgen)
UUID_B=$(uuidgen)

# 2. 將這兩個 UUID 寫入 GRUB 開機選單中（供 Slot A / Slot B 選擇）
sed -i "s/UUID_TMP_A/$UUID_A/g" "$BINARIES_DIR/efi-part/EFI/BOOT/grub.cfg"
sed -i "s/UUID_TMP_B/$UUID_B/g" "$BINARIES_DIR/efi-part/EFI/BOOT/grub.cfg"

log "Change the UUID placeholder to UUID in output/images/efi-part/EFI/BOOT/grub.cfg"

# 3. 將這兩個 UUID 帶入 output/images/genimage-efi.cfg 設定檔中
sed -e "s/UUID_TMP_A/$UUID_A/g" \
    -e "s/UUID_TMP_B/$UUID_B/g" \
    board/pc/genimage-efi.cfg > "$BINARIES_DIR/genimage-efi.cfg"

log "Change the UUID placeholder to UUID in output/images/genimage-efi.cfg"

# recreate grubenv in output/images/efi-part/EFI/BOOT/
if [ -f "$BINARIES_DIR/efi-part/EFI/BOOT/grubenv" ]; then
    rm "$BINARIES_DIR/efi-part/EFI/BOOT/grubenv"
fi

grub-editenv "$BINARIES_DIR/efi-part/EFI/BOOT/grubenv" create	

# set grubenv in output/images/efi-part/EFI/BOOT/
grub-editenv "$BINARIES_DIR/efi-part/EFI/BOOT/grubenv" set saved_entry="rootfsA"
grub-editenv "$BINARIES_DIR/efi-part/EFI/BOOT/grubenv" set boot_success="1"
grub-editenv "$BINARIES_DIR/efi-part/EFI/BOOT/grubenv" set boot_attempt="1"

log "Set the default vallue of grubenv in output/images/efi-part/EFI/BOOT/grubenv"

# copy rootfs.tar to rootfs_origin.tar
cp "$BINARIES_DIR/rootfs.tar" "$BINARIES_DIR/rootfs_origin.tar"

### create the rootfs_update.tar ###
TMP_DIR="$BINARIES_DIR/tmp" 

# recreate tmp workspace
rm -rf "$TMP_DIR"
mkdir -p "$TMP_DIR"

# extract the rootfs.tar 
tar -xf "$BINARIES_DIR/rootfs.tar" -C "$TMP_DIR"

# modify the etc/ota_version
sed -i "s/Version: 1.0.0/Version: 2.0.0/g" "$TMP_DIR/etc/ota-version"
sed -i "s/Build: origin/Build: update/g" "$TMP_DIR/etc/ota-version"

# wrap the roofs_update.tar
tar -cf "$BINARIES_DIR/rootfs_update.tar" -C "$TMP_DIR" .
# clean tmp workspace
rm -rf "$TMP_DIR"/*

log "Created rootfs_origin.tar and rootfs_update.tar in output/images"
### ---------------------------- ###

# now TMP_DIR is clean folder

### create the data.ext2 ###
# move the rootfs_origin.tar and rootfs_update.tar
cp "$BINARIES_DIR/rootfs_origin.tar" "$TMP_DIR/rootfs_origin.tar"
cp "$BINARIES_DIR/rootfs_update.tar" "$TMP_DIR/rootfs_update.tar"
 
### recreate data.ext2
if [ -f "$BINARIES_DIR/data.ext2" ]; then
    rm "$BINARIES_DIR/data.ext2"
fi
mke2fs -d "$TMP_DIR" -t ext2 -F "$BINARIES_DIR/data.ext2" 200M

# remove tmp workspace
# rm -rf "$TMP_DIR"

log "Created the data.ext2 in output/images"
### -------------------- ###

log "Start support/scripts/genimage.sh"
support/scripts/genimage.sh -c "$BINARIES_DIR/genimage-efi.cfg"
